
import xbmc, xbmcgui, shutil, urllib2, urllib, os, xbmcaddon, zipfile, time
#backup trakt	
otrakt_user  =  'NONE'
if not xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.user') == '': 
        otrakt_user = 	xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.user') 
	otrakt_token = 	xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.token')
	otrakt_refresh = 	xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.refresh')
	#xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.user',otrakt_user)
	#xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.token',otrakt_token)
	#xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.refresh',otrakt_refresh)    

#if not xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt_user') == '': 
#	strakt_user = 	xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt_user')
#	strakt_token = 	xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt_oauth_token')
#	strakt_refresh = 	xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt_refresh_token') 
#	#xbmcaddon.Addon(id='plugin.video.water').setSetting('strakt.user',strakt_user)
#	#xbmcaddon.Addon(id='plugin.video.water').setSetting('strakt.token',strakt_token)
#	#xbmcaddon.Addon(id='plugin.video.water').setSetting('strakt.refresh',strakt_refresh)
#

	
import os, re, shutil, time, xbmc, xbmcgui
try:
	import json as simplejson 
except:
	import simplejson

#file = xbmc.translatePath('special://home/addons/service.openeleq/guisettings.xml')
path = xbmc.translatePath('special://home/addons/service.water')
#zip = xbmc.translatePath('special://home/addons/packages/tar.zip')
servicepy = xbmc.translatePath('special://home/addons/service.water/service.py')

def read_from_file(path, silent=False):
	try:
		f = open(path, 'r')
		r = f.read()
		f.close()
		return str(r)
	except:
		return None

def getSetting(setting):
	try:
		setting = '"%s"' % setting 
		query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % (setting)
		response = xbmc.executeJSONRPC(query)
		response = simplejson.loads(response)
		if response.has_key('result'):
			if response['result'].has_key('value'):
				return response ['result']['value'] 
	except:
		pass
	return None

def setSetting(setting, value):
	setting = '"%s"' % setting
	value = '"%s"' % value
	query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (setting, value)
	response = xbmc.executeJSONRPC(query)


	

#cflist = ["HomeMenuNoProgramsButton"]
#ctlist = ["HomeMenuNoMovieButton","HomeMenuNoVideosButton","HomeMenuNoTVShowButton","HomeMenuNoMusicButton","HomeMenuNoMusicButton","HomeMenuNoWeatherButton","HomeMenuNoPicturesButton"]
#appmenu = ["HomeProgramButton1|plugin.video.water"]
if __name__ == '__main__':
	xbmc.executebuiltin("ActivateWindow(Home)")
	setting = 'lookandfeel.skin'
	value = 'skin.confluence'
	current = getSetting(setting)
	setSetting(setting, value)

	while current != 'skin.confluence':
		xbmc.executebuiltin("Action(Select)")
		current = getSetting(setting)
	#for item in cflist:
	#	xbmc.executebuiltin("Skin.Reset("+item+")")
	#for item in ctlist:
	#	xbmc.executebuiltin("Skin.SetBool("+item+")")
	#for item in appmenu:
	#	string = item.split('|')
	#	xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")
	setting = 'weather.addon'
	value = 'weather.yahoo'
	#current = getSetting(setting)
	setSetting(setting, value)
	setting = 'audiooutput.stereoupmix'
	value = 'true'
	#current = getSetting(setting)
	setSetting(setting, value)
	setting = 'defaultvideosettings.viewmode'
	value = '4'
	#current = getSetting(setting)
	setSetting(setting, value)	
	setting = 'defaultvideosettings.postprocess'
	value = 'true'
	#current = getSetting(setting)
	setSetting(setting, value)
	setting = 'lookandfeel.soundskin'
	value = ''
	#current = getSetting(setting)
	setSetting(setting, value)

		

bflist = ["HolidayEffects"]
#true list ?
#blist = ["MusicFullscreen","homepageWeatherinfo","SystemDate","SystemWeatherinfo","AutoScroll","FirstTimeRun","ArtistSlideshow","SkinMod"]
btlist = ["EnableFloorReturnButtons","LowerMainMenuBar", "HideTopLeftWindows", "AllScreenTopLeftWidget", "HidePageCountInfo","DisableGlobalSearch", "HideBackGroundFanart", "InitialSetUpRun", "HideHomeFloor","HideInfoStartOSD","SingleGlobalBackground"]
# variable

BG1 = 'special://home/addons/script.supafav/BG'
moviemenu = ["HomeItem.1.Widget|plugin://plugin.video.origin2/?action=movies&url=trending","HomeItem.1.Label|Movies","HomeItem.1.type|Movies","HomeItem.1.sub|Movies","HomeItem.1.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=40&url=null"",return)", "HomeItem.1.Fanart|special://home/addons/script.supafav/BG" ,        "SubMovies.1.Label|[B][COLOR white]Recent[/COLOR][/B]ly Added","SubMovies.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=20"",return)",       "SubMovies.2.Label|By [B][COLOR white]Year[/COLOR][/B]","SubMovies.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=23"",return)",        "SubMovies.3.Label|[B]G[COLOR white]enres[/COLOR][/B]","SubMovies.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=24"",return)",           "SubMovies.4.Label|By [B][COLOR white]Actors[/COLOR][/B]","SubMovies.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=27"",return)",           "SubMovies.5.Label|[B][COLOR white]Search [COLOR steelblue]Movies[/COLOR][/B]","SubMovies.5.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=30"",return)",           "SubMovies.6.Label|Hidden","SubMovies.6.Path|Hidden","SubMovies.7.Label|Hidden","SubMovies.7.Path|Hidden",       "AddonSetOne.1.Path|ActivateWindow(10025,""plugin://plugin.video.origin2/?action=channels"" ,return)", "HomeItem.1.Addon|AddonSetOne", "AddonSetOne.1.label|Random Movies", "AddonSetOne.1.Icon|http://downloadicons.net/sites/default/files/random-play-button-icon-blue-40192.png", "AddonSetOne.2.Path|", "AddonSetOne.2.label|", "AddonSetOne.2.Icon|", "AddonSetOne.3.Path|", "AddonSetOne.3.label|", "AddonSetOne.3.Icon|"]

tvmenu = ["HomeItem.2.Widget|plugin://plugin.video.tvmix/?description&mode=1&name=New%20Latest%20Episodes&url=http%3a%2f%2fwww.watchepisodes1.com%2f", "HomeItem.2.Label|TV Shows","HomeItem.2.sub|TV Shows","HomeItem.2.sub|TVShows","HomeItem.2.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=50&url=null"",return)", "HomeItem.2.Fanart|special://home/addons/script.supafav/BG"   ,       "SubTVShows.1.Label|[B][COLOR white]Recent[/COLOR][/B]ly Added","SubTVShows.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=21"",return)",          "SubTVShows.2.Label|[B][COLOR white]New[/COLOR][/B] Shows","SubTVShows.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=22"",return)",        "SubTVShows.4.Label|[B]G[COLOR white]enres[/COLOR][/B]","SubTVShows.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=25"",return)",          "SubTVShows.3.Label|[B]By [COLOR white]Network[/COLOR][/B]","SubTVShows.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=26"",return)",        "SubTVShows.5.Label|[B][COLOR white]Search[/COLOR] [COLOR steelblue]TV[/COLOR][/B]","SubTVShows.5.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=31"",return)"]

livemenu = ["HomeItem.3.Widget|plugin://plugin.video.ustvnow.tva/?mode=live","HomeItem.3.Label|Live TV","HomeItem.3.type|Movies","HomeItem.3.Addon|AddonSetThree","HomeItem.3.sub|LiveTV","HomeItem.3.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=60&url=null"",return)",   "HomeItem.3.Fanart|special://home/addons/script.supafav/BG",        "SubLiveTV.1.Label|[B]N[COLOR white]ews[/COLOR][/B]","SubLiveTV.1.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=62"",return)",          "SubLiveTV.2.Label|[B]S[COLOR white]ports[/COLOR][/B]","SubLiveTV.2.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=63"",return)",        "SubLiveTV.3.Label|[B]S[COLOR white]hows[/COLOR][/B]","SubLiveTV.3.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=65"",return)",          "SubLiveTV.4.Label|[B]F[COLOR white]oreign[/COLOR][/B]","SubLiveTV.4.Path|ActivateWindow(10025,""plugin://plugin.video.water/?url=null&mode=64"",return)",        "SubLiveTV.5.Label|Hidden","SubLiveTV.5.Path|Hidden","SubLiveTV.6.Label|Hidden","SubLiveTV.6.Path|Hidden","SubLiveTV.7.Label|Hidden","SubLiveTV.7.Path|Hidden","SubLiveTV.9.Label|Hidden","SubLiveTV.9.Path|Hidden","AddonSetThree.1.label|TV Guide","AddonSetThree.1.Path|ActivateWindow(10025,plugin://plugin.video.water/?url=null&action=tvguide,return)", "AddonSetThree.1.Icon|http://rocketdock.com/images/screenshots/TV-Guide.png"]


newsmenu = ["HomeItem.4.Widget|plugin://plugin.program.super.favourites/?folder=news","HomeItem.4.Label|News","HomeItem.4.type|Videos","HomeItem.4.Addon|AddonSetFour","HomeItem.4.sub|News","HomeItem.4.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=62&url=null"",return)"]
sportsmenu = ["HomeItem.5.Widget|plugin://plugin.program.super.favourites/?folder=sports","HomeItem.5.Label|Sports","HomeItem.5.type|Videos","HomeItem.5.Addon|AddonSetFive","HomeItem.5.sub|Sports","HomeItem.5.path|ActivateWindow(10025,""plugin://plugin.video.water/?mode=63&url=null"",return)"]
youtube = ["HomeItem.8.Widget|plugin://plugin.video.youtube/special/popular_right_now/","HomeItem.8.Label|YouTube","HomeItem.8.type|Videos","HomeItem.8.Addon|AddonSetTen","HomeItem.8.sub|Concerts", "UserConcertsSubMenu|YouTube","HomeItem.8.path|ActivateWindow(10025,""plugin://plugin.video.youtube/"",return)","HomeItem.8.Fanart|http://orig04.deviantart.net/4b0f/f/2011/281/a/7/youtube_wallpaper_by_paintingwalls11-d4c6tuv.png", "SubConcerts.1.Label|[B]S[COLOR white]earch[/COLOR][/B]","SubConcerts.1.Path|ActivateWindow(10025,""plugin://plugin.video.youtube/kodion/search/list/"",return)" ,"SubConcerts.2.Label|[B]B[COLOR white]rowse[/COLOR][/B]","SubConcerts.2.Path|ActivateWindow(10025,""plugin://plugin.video.youtube/special/browse_channels/"",return)","SubConcerts.3.Label|[B]L[COLOR white]ive[/COLOR][/B]","SubConcerts.3.Path|ActivateWindow(10025,""plugin://plugin.video.youtube/special/live/"",return)","SubConcerts.4.Path|Hidden","SubConcerts.5.Path|Hidden", "SubConcerts.6.Label|Hidden" ]



moremenu = ["HomeItem.7.Label|[B][COLOR steelblue]M[/COLOR]ORE[/B]","HomeItem.7.Widget|Weather",   "HomeItem.7.Fanart|special://home/addons/script.supafav/BG", "HomeItem.7.type|System", "HomeItem.7.Addon|AddonSetTwelve", "HomeItem.7.sub|Settings", "HomeItem.7.path|ActivateWindow(Settings))", "HomeItem.7.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=more"",return)",         "SubSettings.1.Label|[B]S[COLOR white]ettings[/COLOR][/B]","SubSettings.1.Path|ActivateWindow(Settings)", "SubSettings.2.Path|Hidden", "SubSettings.3.Path|Hidden", "SubSettings.4.Path|Hidden", "SubSettings.5.Path|Hidden", "SubSettings.6.Path|Hidden",      "AddonSetTwelve.1.Path|ActivateWindow(10025,""plugin://plugin.video.youtube/"" ,return)", "AddonSetTwelve.1.label|YouTube", "AddonSetTwelve.1.Icon|http://www.usacapitol.com/SiteAssets/stay-connected/youtube-logo.png",                  "AddonSetTwelve.2.label|Music", "AddonSetTwelve.2.Icon|",                     "AddonSetTwelve.4.label|KidsTV", "AddonSetTwelve.4.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=More/KidsTV"",return)", "AddonSetTwelve.4.Icon|http://icons.iconarchive.com/icons/martin-berube/people/256/kid-icon.png" ,     "AddonSetTwelve.3.label|Documentaries","AddonSetTwelve.3.Path|ActivateWindow(10025,""plugin://plugin.program.super.favourites/?folder=More/Documentaries"",return)", "AddonSetTwelve.3.Icon|https://solutionsmedia.cbcrc.ca/Pictures/chaineslogos/CBC_documentary_blanc_15.png", "AddonSetTwelve.3.Icon|http://www.filmsite.org/images/documentary-genre.jpg",  "AddonSetTwelve.5.label|Stand-Up","AddonSetTwelve.5.Path|ActivateWindow(10025,""plugin://plugin.video.phstreams/?action=directory&url=http%3a%2f%2fone242415.offshorepastebin.com%2fCollections%2fStandup.xml"",return)", "AddonSetTwelve.5.Icon|https://lh6.ggpht.com/JH8vf9T54XQET1h-BgpvZrXedGkWEqG-K9DSgf_TXlU2r0WpM3NlZ817a3F9Ch83aBg=w150","AddonSetTwelve.6.Path|"]

hiddenmenu = ["GlobalBackgroundPath|special://home/addons/script.supafav/BG/","TopLeftHomeInfo|Weather","HomeItem.4.path|","HomeItem.5.path|","HomeItem.6.path|","HomeItem.8.path|","HomeItem.9.path|","HomeItem.10.path|","HomeItem.11.path|","HomeItem.12.path|","PowerBtnAction|Exit"]
	
if __name__ == '__main__':
	
	xbmc.executebuiltin("ActivateWindow(Home)")
	
	setting = 'lookandfeel.skin'
	value = 'skin.water2'
	current = getSetting(setting)
	setSetting(setting, value)
	

	
	while current != 'skin.water2':
		xbmc.executebuiltin("Action(Select)")
		current = getSetting(setting)
	for item in bflist:
		xbmc.executebuiltin("Skin.Reset("+item+")")
	for item in btlist:
		xbmc.executebuiltin("Skin.SetBool("+item+")")
	for item in moviemenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")
	for item in tvmenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	for item in livemenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	for item in newsmenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	for item in sportsmenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")
	for item in moremenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	for item in youtube:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")		
	for item in hiddenmenu:
		string = item.split('|')
		xbmc.executebuiltin("Skin.SetString("+string[0]+","+string[1]+")")	
	#shutil.rmtree(path)
	#os.remove(lib)
	time.sleep(1)
	xbmc.executebuiltin("Notification(wTV,Updated,5000,https://lh6.ggpht.com/dL9--GgOGLaQxycrYCgvyyxU-dn6L9_eHf73Exwm_D8_1aciSfGEFCxcMs6jRc-hmf4c=w300)")

	
	#setting = 'services.devicename'
	#value = 'WTV'
	##current = getSetting(setting)
	#setSetting(setting, value)


	
	#setting = 'lookandfeel.skin'
	#value = 'skin.water2'
	##current = getSetting(setting)
	#setSetting(setting, value)

import xbmc, xbmcgui, shutil, urllib2, urllib, os, xbmcaddon, zipfile, time
addon = xbmcaddon.Addon('service.autoclean')
url        = 'https://raw.githubusercontent.com/watermouf/sanjuan/master/repo/service.autoclean/service.autoclean.zip'
path       = xbmc.translatePath('special://home/addons/packages')
lib        = xbmc.translatePath(os.path.join(path,'autoclean.zip'))
home       = xbmc.translatePath('special://home')
profile    = 'Master user'
lock       = 'false'
localtxt00 = 'Update'
localtxt01 = 'Install'
localtxt02 = 'Downloading. Please Wait.'
localtxt03 = 'Downloaded: '
localtxt04 = 'Download Cancelled.'
localtxt05 = 'Updating'
localtxt06 = 'Succeeded'
localtxt07 = 'Installing. Please Wait.'

def DownloaderClass(url,dest):
	dp = xbmcgui.DialogProgress()
	dp.create(localtxt00,localtxt02,'')
	urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
		percent = min((numblocks*blocksize*100)/filesize, 100)
		print localtxt03+str(percent)+'%'
		dp.update(percent)
	except:
		percent = 100
		dp.update(percent)
	#if dp.iscanceled(): 
		#raise Exception("Cancelled")
		#dp.close()

def ExtractorClass(_in, _out):
	dp = xbmcgui.DialogProgress()
	dp.create(localtxt00,localtxt07,'')
	zin    = zipfile.ZipFile(_in,  'r')
	nFiles = float(len(zin.infolist()))
	count  = 0
	for item in zin.infolist():
		count += 1
		update = count / nFiles * 100
		zin.extract(item, _out)

if __name__ == '__main__':
	dialog = xbmcgui.Dialog()
	try:
		DownloaderClass(url,lib)
	except:
		xbmc.executebuiltin('Notification(Download Failed,Please Try Again Later,50000,special://skin/icon.png)')
	time.sleep(1)
	try:
		ExtractorClass(lib,home)
	except:
		xbmc.executebuiltin('Notification(Unpacking Failed,Please Try Again Later,50000,special://skin/icon.png)')
	#time.sleep(1)
	os.remove(xbmc.translatePath('special://home/addons/packages/autoclean.zip'))
	xbmc.executebuiltin('UpdateLocalAddons')
	xbmc.executebuiltin('UpdateAddonRepos')
	#xbmc.executebuiltin('RunScript(service.installer)')
	#restore trakt		
    #dp.create(localtxt00,'SYSTEM MAY HANG FOR FEW MINUTES','')
	
	
	
if not otrakt_user == 'NONE': 	
    xbmcaddon.Addon(id='plugin.video.origin2').setSetting('trakt.user',otrakt_user)
    xbmcaddon.Addon(id='plugin.video.origin2').setSetting('trakt.token',otrakt_token)
    xbmcaddon.Addon(id='plugin.video.origin2').setSetting('trakt.refresh',otrakt_refresh)
#xbmcaddon.Addon(id='plugin.video.salts').setSetting('trakt_user',strakt_user)
#xbmcaddon.Addon(id='plugin.video.salts').setSetting('trakt_oauth_token',strakt_token)
#xbmcaddon.Addon(id='plugin.video.salts').setSetting('trakt_refresh_token',strakt_refresh)  

	
#if xbmcaddon.Addon(id='plugin.video.origin2').getSetting('trakt.user') == '':
    #if not xbmcaddon.Addon(id='plugin.video.water').getSetting('trakt.user') == '':
        #otrakt_user = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('otrakt.user')
        #otrakt_token = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('otrakt.token')
        #otrakt_refresh = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('otrakt.refresh')
		
     
        #xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.user','')
        #xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.token','')
        #xbmcaddon.Addon(id='plugin.video.water').setSetting('otrakt.refresh','')
		
#if xbmcaddon.Addon(id='plugin.video.salts').getSetting('trakt.user') == '':
    #if not xbmcaddon.Addon(id='plugin.video.water').getSetting('trakt.user') == '':	
	        #strakt_user = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('strakt_user')
	        #strakt_token = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('strakt_oauth_token')
	        #strakt_refresh = 	xbmcaddon.Addon(id='plugin.video.water').getSetting('trakt_refresh_token') 

			


			
