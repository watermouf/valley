import xbmc

def logoff():
	xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.youtube/play/?playlist_id=PL2wOao9a7O2MQeOpykso4_zKAbOkvlA0I&amp;order=shuffle&amp;play=1")')
if not xbmc.Player().isPlayingAudio():
	logoff()